# Dannie Fumigation Services — Android App v2.1

Kotlin + Jetpack Compose Android project for Dannie Fumigation Services.

## Updated in this version
- Uses the supplied Dannie Fumigation Services logo throughout the app.
- Bundles the supplied bedbug, termite, mosquito and cockroach photos inside the APK.
- Removes all remote pest-photo URLs.
- Removes the Coil image-loading dependency.
- Service cards and service-detail pages use local images, so they do not need to download photographs from other websites.
- Version bumped to 2.1 (versionCode 3).

## Build requirements
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Compile/target SDK 35
- Minimum Android API 24 (Android 7.0)
- JDK 17 is recommended for this project.

## Build on an Android phone
1. Install a compatible Android Gradle IDE such as AndroidIDE from a trusted source.
2. Extract this ZIP and open the folder containing `settings.gradle.kts`.
3. Select/use JDK 17 in the IDE.
4. Make sure Android SDK 35 and the required build tools are installed.
5. Let Gradle sync/download dependencies.
6. Run the `assembleDebug` build.
7. The APK will be under `app/build/outputs/apk/debug/`.

## Important
The original project did not include a Gradle wrapper. AndroidIDE can manage Gradle for an imported project; if your IDE specifically requires `gradlew`, use its Gradle/wrapper generation command before building.

The WhatsApp and Facebook buttons open external apps/browser pages; the app itself no longer downloads service photographs from the web.

## Build the APK with GitHub Actions (phone-friendly)

This project includes `.github/workflows/build-apk.yml`. After uploading the project to a GitHub repository:

1. Open the repository on GitHub.
2. Open **Actions**.
3. Select **Build Dannie Fumigation APK**.
4. Tap **Run workflow** and choose the `main` branch.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run and download the **Dannie-Fumigation-debug-APK** artifact.
7. Extract the APK and install it on your Android phone.

The workflow installs JDK 17, Android SDK 35, and Gradle 8.9 on GitHub's build machine. This matches this project's Android Gradle Plugin 8.7.3 requirements.
